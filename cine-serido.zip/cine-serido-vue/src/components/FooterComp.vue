<template>
    <footer class="site-footer">

        <div class="col-lg-12 col-12">
            <div class="section-title-wrap mb-5">
            </div>
        </div>

        <div class="container text-center pt-0" id="contato">
            <div class="row">
                <div class="col-lg-6 col-12 mb-5 mb-lg-0">

                    <iframe class="google-map"
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3988.819917806043!2d103.84793601429608!3d1.281807962148459!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31da190c2c94ccb3%3A0x11213560829baa05!2sTwitter!5e0!3m2!1sen!2smy!4v1669212183861!5m2!1sen!2smy"
                        width="100%" height="300" style="border:0;" allowfullscreen="" loading="lazy"
                        referrerpolicy="no-referrer-when-downgrade"></iframe>

                </div>

                <div class="col-lg-6 col-md-6 col-12 mb-4 mb-md-0 mb-lg-0">
                    <h6 class="site-footer-title mb-3">Contato</h6>

                    <p class="mb-2"><strong class="d-inline me-2">Telefone/Whatsapp:</strong>(84) 9.9987-0125</p>

                    <p><strong class="d-inline me-2">Email:</strong><a href="#">cineserido@gmail.com</a></p>

                    <p><strong class="d-inline me-2">Instagram:</strong><a href="#">@cine_serido</a></p>

                    <h6 class="site-footer-title mb-3">Avalie o CineSeridó!</h6>

                    <p><strong class="d-inline me-2">Formulário:</strong><a>Acesse o
                            questionário</a></p>

                </div>



            </div>
        </div>
    </footer>
</template>

<script>
export default {
    name: 'FooterComp'
}
</script>

<style lang="scss" scoped></style>