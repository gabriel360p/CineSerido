<template>
    <div class="col-lg-6 col-12 mb-4  mt-4 mb-lg-0">
        <div class="custom-block d-flex align-items-center">
            <div style="width: 30%">
                <a class="custom-block-image-wrap"><img
                        :src="lancamento.img" class=" img-fluid"
                        :alt="lancamento.title"></a>
            </div>

            <div class="custom-block-info" id="block-info" style="width: 70%; text-align: justify;">
                <div class="custom-block-top d-flex mb-1">
                    <small class="me-4"><i class="bi-clock-fill custom-icon"></i>
                        {{ lancamento.time }}</small>
                </div>

                <h5 class="mb-2" id="movie-title"><a>{{ lancamento.title }}</a>
                </h5>

                <p class="mb-0" style="font-size: 15px;" id="teste">
                    {{ lancamento.description }}
                </p>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    name:'CardLancamento',
    props: {
        lancamento:Object  
    },
    data() {
        return {
            title: this.lancamento.title,
            description: this.lancamento.description,
            img: this.lancamento.img,
            time: this.lancamento.time,
        }
    },
}
</script>

<style lang="scss" scoped></style>