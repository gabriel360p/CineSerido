<template>
    <section id="lançamentos">
        <div class="container">
            <div class="row justify-content-center">

                <div class="col-lg-12 col-12">
                    <div class="section-title-wrap mb-5">
                        <h4 class="section-title">Lançamentos</h4>
                    </div>
                </div>

                <CardLancamento v-for="lancamento in data_lancamentos" :key="lancamento.id" :lancamento="lancamento" />

            </div>

        </div>
    </section>
</template>

<script>
import CardLancamento from './CardLancamento.vue';

export default {
    name: 'LancamentoComp',
    components: {
        CardLancamento,
    },
    data() {
        return {
            data_lancamentos: {
                lancamento1: {
                    id: 1,
                    title: "Five Nights at Freddy's - O Pesadelo Sem Fim",
                    description: "No Freddy Fazbear's Pizza, robôs animados fazem a festa das crianças durante o dia.Mas, quando chega a noite, eles se transformam em assassinos psicopatas",
                    img: "https://i.postimg.cc/hjHdfYR4/five-Nights.jpg",
                    time: "109 Minutos",
                },
                lancamento2: {
                    id: 2,
                    title: "A freira 2",
                    description: "Em 1956, na França, um padre é assassinado e parece que um mal está se espalhando. Determinada a deter o maligno, irmã Irene mais uma vez fica cara a cara com uma força demoníaca.",
                    img: "https://i.postimg.cc/pdL878Bv/freira2.webp",
                    time: "110 Minutos",
                },
                lancamento3: {
                    id: 3,
                    title: "Guardiões da Galáxia: Volume 3",
                    description: "Peter Quill deve reunir sua equipe para defender o universo e proteger um dos seus. Se a missão não for totalmente bem-sucedida, isso pode levar ao fim dos Guardiões.",
                    img: "https://i.postimg.cc/G2BD3CNS/guardios-Galaxia3.jpg",
                    time: "147 Minutos",
                },
                lancamento4: {
                    id: 4,
                    title: "Vermelho branco e sangue azul",
                    description: "Alex, o filho da presidenta dos Estados Unidos, se envolve em uma confusão com o príncipe britânico Henry, o que gera uma crise internacional de imagem. Os dois são grandes rivais, mas fingem que são amigos pelo bem de seus países. Porém, essa relação fria começa a derreter e dá lugar a um sentimento intenso e novo para os dois.",
                    img: "https://i.postimg.cc/s2HSRXnh/rwrb.webp",
                    time: "118 Minutos",
                },

            },

        }
    },
}
</script>

<style lang="scss" scoped></style>