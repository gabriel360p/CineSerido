<template>
    <nav class="navbar navbar-expand-lg ">
        <div class="container">
            <a class="navbar-brand me-lg-5 me-0">
                <img src="logo.png" class="logo-image img-fluid" alt="" style="width: 140px;">
            </a>

            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-lg-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="">Início</a>

                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#lançamentos">Lançamentos</a>

                    </li>

                    <li class="nav-item">
                        <a class="nav-link " href="#em-breve">Em Breve</a>

                    </li>

                    <li class="nav-item">
                        <a class="nav-link " href="#combos">Combos</a>

                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="#contato">Contato</a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="">Sobre</a>
                    </li>


                </ul>

            </div>
        </div>
    </nav>
</template>

<script>
export default {
    name: 'NavBar'
}
</script>

<style lang="scss" scoped></style>