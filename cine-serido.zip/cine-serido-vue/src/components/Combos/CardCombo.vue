<template>
    <div class="col-lg-4 col-12 mb-4 mb-lg-0">
        <div class="custom-block custom-block-full">
            <div class="custom-block-image-wrap">

                <img :src="combo.img" class="custom-block-image img-fluid" alt="">

            </div>

            <div class="custom-block-info">
                <h5 class="mb-2">

                    {{ combo.title }}

                </h5>

                <div class="profile-block d-flex">
                    <p> {{ combo.price }}
                    </p>
                </div>

                <p class="mb-0"> {{ combo.description }}
                </p>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    name: 'CardCombo',
    props: {
        combo: Object,
    },
    data() {
        return {
            title: this.combo.title,
            price: this.combo.price,
            description: this.combo.description,
            img: this.combo.img
        }
    },
}
</script>

<style lang="scss" scoped></style>