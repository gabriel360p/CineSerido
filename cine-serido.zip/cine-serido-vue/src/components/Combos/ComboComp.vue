<template>
    <section id="combos">
        <div class="container">
            <div class="row">

                <div class="col-lg-12 col-12">
                    <div class="section-title-wrap mb-5">
                        <h4 class="section-title">Combos</h4>
                    </div>
                </div>

                <CardCombo v-for="combo in data_combos" :key="combo.id" :combo="combo" />

            </div>
        </div>
    </section>
</template>

<script>
import CardCombo from './CardCombo.vue';

export default {
    name: 'ComboComp',
    components: {
        CardCombo,
    },
    data() {
        return {
            data_combos: {
                combo1: {
                    id: 1,
                    title: "Combo Kids",
                    img: "https://i.postimg.cc/d0f7xf1R/combo1.png",
                    description: "2 Pipocas P, 2 sucos, água 500ml e Bis.",
                    price: "R$ 20,00",
                },
                combo2: {
                    id: 2,
                    title: "Combo Tradicional",
                    img: "https://i.postimg.cc/tJQsXVFY/combo2.jpg",

                    description: "Balde de pipoca, 2 refrigerantes 350ml e chocolate em barra",
                    price: "R$ 40,00",
                },
                combo3: {
                    id: 3,
                    title: "Combo Premium",
                    img: "https://i.postimg.cc/zBRLZkbs/combo3.webp",

                    description: "Balde de pipoca, Pipoca P, 3 refrigerantes 350ml e chocolate em barra",
                    price: "R$ 60,00"
                }
            },

        }
    },
}
</script>

<style lang="scss" scoped></style>