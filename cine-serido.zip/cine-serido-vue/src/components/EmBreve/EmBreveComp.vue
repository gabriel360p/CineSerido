<template>
    <section id="em-breve">
        <div class="container">
            <div class="row">

                <div class="col-lg-12 col-12">
                    <div class="section-title-wrap mb-5">
                        <h5 class="section-title">Em Breve</h5>
                    </div>
                </div>


                <CardEmBreve v-for="breve in data_embreve" :key="breve.id" :breve="breve" />

            </div>
        </div>
    </section>
</template>

<script>
import CardEmBreve from './CardEmBreve.vue';

export default {
    name: 'EmBreveComp',
    components: {
        CardEmBreve,
    },
    data() {
        return {
            data_embreve: {
                breve1: {
                    id: "1",
                    img: "https://i.postimg.cc/brcNmpsr/marvels.jpg",
                    title: "As Marvels",
                    categorias: "Aventura/Ação",
                },
                breve2: {
                    id: "2",
                    img: "https://i.postimg.cc/qRCvczBW/madame-web.jpg",
                    title: "Madame Web",
                    categorias: "Ficção científica/Aventura",
                },
                breve3: {
                    id: "3",
                    img: "https://i.postimg.cc/FzyFq8LZ/spiderman.webp",
                    title: "Homem-Aranha: Além do Aranhaverso",
                    categorias: "Ficção científica/Aventura",
                },
                breve4: {
                    id: "4",
                    img: "https://i.postimg.cc/Hsmk5YqP/wonka.webp",
                    title: "Wonka",
                    categorias: "Fantasia/Aventura",
                },
            }
        }
    },

}
</script>

<style lang="scss" scoped></style>