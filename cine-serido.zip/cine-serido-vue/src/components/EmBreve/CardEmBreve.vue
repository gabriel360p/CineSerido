<template>
    <div class="col-lg-3 col-md-6 col-12 mb-4 mb-lg-0">
        <div class="custom-block custom-block-overlay">

            <span href="" class="custom-block-image-wrap">
                <a>
                    <img :src="breve.img" class="custom-block-image img-fluid" alt="">
                </a>
            </span>

            <div class="custom-block-info custom-block-overlay-info">
                <h5 style="color:#B5121B;" class="mb-1"><span>

                            <a >

                                {{ breve.title }}</a></span></h5><a >
                    </a>

                    <p class=" badge mb-0"> {{ breve.categorias }} </p>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    name: 'CardEmBreve',
    props: {
        breve: Object
    },
    data() {
        return {
            title: this.breve.title,
            img: this.breve.img,
            categorias: this.breve.categorias,
        }
    },
}
</script>

<style lang="scss" scoped></style>