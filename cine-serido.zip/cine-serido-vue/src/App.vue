<template>
  <body>

    <NavBar />

    <main>
      <section class="hero-section">
        <div class="container">
          <div class="row">

            <div class="col-lg-12 col-12">
              <div class="text-center mb-5 pb-2">
                <h1 class="text-white">Lançamentos </h1>
                <a href="#lançamentos" class="btn custom-btn smoothscroll mt-3">Em Cartaz</a>
              </div>
<!-- 
              <div class="owl-carousel owl-theme">
                <div class="owl-carousel-info-wrap item">
                  <img src="assets/imgs/movies/rwrb2.jpeg" class="owl-carousel-image img-fluid" alt="">

                  <div class="owl-carousel-info">
                    <h4 class="mb-2">
                      Vermelho Branco e Sangue Azul
                    </h4>

                    <span class="badge">Romance</span>
                  </div>

                </div>


                <div class="owl-carousel-info-wrap item">
                  <img src="assets/imgs/movies/freira2.webp" class="owl-carousel-image img-fluid" alt="">

                  <div class="owl-carousel-info">
                    <h4 class="mb-2">
                      A Freira 2
                    </h4>

                    <span class="badge">Terror</span>

                    <span class="badge">Mistério</span>
                  </div>
                </div>

                <div class="owl-carousel-info-wrap item">
                  <img src="assets/imgs/movies/rwrb2.jpeg" class="owl-carousel-image img-fluid" alt="">

                  <div class="owl-carousel-info">
                    <h4 class="mb-2">
                      Vermelho Branco e Sangue Azul
                    </h4>

                    <span class="badge">Romance</span>
                  </div>

                </div>

                <div class="owl-carousel-info-wrap item">
                  <img src="assets/imgs/movies/guardiosGalaxia3.jpg" class="owl-carousel-image img-fluid" alt="">

                  <div class="owl-carousel-info">
                    <h4 class="mb-2">Guardiões da Galáxia Vol. 3</h4>

                    <span class="badge">Científica</span>

                    <span class="badge">Ação</span>
                  </div>
                </div>

                <div class="owl-carousel-info-wrap item">
                  <img src="assets/imgs/movies/fiveNights.jpg" class="owl-carousel-image img-fluid" alt="">

                  <div class="owl-carousel-info">
                    <h4 class="mb-2">Five Nights at Freddy's</h4>

                    <span class="badge">Terror</span>

                  </div>

                </div>

              </div> -->

            </div>

          </div>
        </div>
      </section>

      <LancamentoCompVue />
      <EmBreveCompVue />
      <ComboCompVue />

    </main>

    <FooterComp />

  </body>
</template>

<script>

import NavBar from './components/NavBar.vue'
import FooterComp from './components/FooterComp.vue';
import ComboCompVue from './components/Combos/ComboComp.vue';
import EmBreveCompVue from './components/EmBreve/EmBreveComp.vue';
import LancamentoCompVue from './components/Lancamentos/LancamentoComp.vue';

export default {
  name: 'App',
  components: {
    NavBar,
    FooterComp,
    ComboCompVue,
    EmBreveCompVue,
    LancamentoCompVue,
  },

}
</script>


